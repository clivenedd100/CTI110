def gasCost(miles, mpg, dollar_per_gallon):
    gallon = miles / mpg
    cost = gallon * dollars_per_gallon
    return cost

mpg = float(input(''))

dollars_per_gallon = float(input(''))


gas_cost_20miles=gasCost(20, mpg, dollars_per_gallon)

gas_cost_75miles=gasCost(75, mpg, dollars_per_gallon)

gas_cost_500miles=gasCost(500, mpg, dollars_per_gallon)

print(f'{gas_cost_20miles:.2f} {gas_cost_75miles:.2f} {gas_cost_500miles:.2f}')


