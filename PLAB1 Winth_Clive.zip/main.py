user_name = "June"
print("hello +user_name+ and Welcome to CS online!")